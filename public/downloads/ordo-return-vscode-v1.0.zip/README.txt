ORDO Return · VS Code

VS Code extension
Version: v1.0

Placeholder package for local staging.
Replace with the real artifact when ready.
