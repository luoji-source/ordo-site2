ORDO Return · Notion

Notion plugin
Version: v1.0

Placeholder package for local staging.
Replace with the real artifact when ready.
